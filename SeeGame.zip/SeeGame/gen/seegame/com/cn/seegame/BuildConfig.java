/** Automatically generated file. DO NOT MODIFY */
package seegame.com.cn.seegame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}