package seegame.com.cn.seegame.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import seegame.com.cn.seegame.R;

/**
 * 自定义Toast显示的样式
 * 
 */

@SuppressLint("ResourceAsColor")
public class MyToast {
	public static void myTosat(Context context, String content, int duration,int size) {
		// new一个toast传入要显示的activity的上下文
		Toast toast = new Toast(context);
		// 显示的时间
		toast.setDuration(duration);
		// 显示的位置
		toast.setGravity(Gravity.CENTER, 0, 100);
		// 重新给toast进行布局
		LinearLayout toastLayout = new LinearLayout(context);
		toastLayout.setOrientation(LinearLayout.HORIZONTAL);
		toastLayout.setGravity(Gravity.CENTER);
		TextView textView = new TextView(context);
		textView.setText(content);
		textView.setTextSize(size);
		textView.setTextColor(Color.WHITE);
		// 把textView添加到toastLayout的布局当中
		toastLayout.addView(textView);
		toastLayout.setMinimumWidth(860);
		toastLayout.setMinimumHeight(1000);
		toastLayout.setBackgroundColor(R.color.color_gray);
		// 把toastLayout添加到toast的布局当中
		toast.setView(toastLayout);
		toast.show();
	}
}
