package seegame.com.cn.seegame.util;

import android.content.Context;
import android.content.SharedPreferences;
import seegame.com.cn.seegame.constant.Constant;

public class SharedPreferencesUtils {

	public static SharedPreferences getPreferences(Context context) {
		SharedPreferences preferences = context.getSharedPreferences(Constant.SHARED_NAME, Context.MODE_PRIVATE);
		return preferences;
	}

	public static String getStringPreferences(Context context, String preferencesKey) {
		SharedPreferences preferences = context.getSharedPreferences(Constant.SHARED_NAME, Context.MODE_PRIVATE);
		String preferencesValue = preferences.getString(preferencesKey,"");
		return preferencesValue;
	}

	public static int getIntPreferences(Context context, String preferencesKey) {
		SharedPreferences preferences = context.getSharedPreferences(Constant.SHARED_NAME, Context.MODE_PRIVATE);
		int preferencesValue = preferences.getInt(preferencesKey, 0);
		return preferencesValue;
	}

	public static boolean getBooleanPreferences(Context context, String preferencesKey) {
		SharedPreferences preferences = context.getSharedPreferences(Constant.SHARED_NAME, Context.MODE_PRIVATE);
		boolean preferencesValue = preferences.getBoolean(preferencesKey, false);
		return preferencesValue;
	}

	public static void setIntValue(Context context, String preferencesKey, int value) {
		SharedPreferences sp = context.getSharedPreferences(Constant.SHARED_NAME, Context.MODE_PRIVATE);
		sp.edit().putInt(preferencesKey, value).commit();
	}

	public static void setStringValue(Context context, String preferencesKey, String value) {
		SharedPreferences sp = context.getSharedPreferences(Constant.SHARED_NAME, Context.MODE_PRIVATE);
		sp.edit().putString(preferencesKey, value).commit();
	}

	public static void setBooleanValue(Context context, String preferencesKey, boolean value) {
		SharedPreferences sp = context.getSharedPreferences(Constant.SHARED_NAME, Context.MODE_PRIVATE);
		sp.edit().putBoolean(preferencesKey, value).commit();
	}
}
