package seegame.com.cn.seegame.util;

import java.util.HashMap;//引入HashMap类
import java.util.Map;
import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.SoundPool;
import seegame.com.cn.seegame.R;

public class SoundPoolUtil {
	@SuppressLint("UseSparseArrays")//
	private Map<Integer, Integer> soundMap = new HashMap<Integer, Integer>();
	private MediaPlayer mp;// mediaPlayer对象
	private SoundPool soundPool;
	/**
	 * 自身引用
	 */
	private static SoundPoolUtil instance = null;
	Context context;
	int mPath;

	/**
	 * 获取实例
	 * @return
	 */
	public static SoundPoolUtil getInstance(Context context) {

		if (instance == null)
			instance = new SoundPoolUtil(context);
		return instance;
	}

	@SuppressWarnings("deprecation")
	public SoundPoolUtil(Context context) {
		this.context = context;
		soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		// load方法加载音频文件返回对应的ID
		soundMap.put(1, soundPool.load(context, R.raw.five, 1));
		soundMap.put(2, soundPool.load(context, R.raw.two, 1));
		soundMap.put(3, soundPool.load(context, R.raw.three, 1));
		soundMap.put(4, soundPool.load(context, R.raw.seven, 1));
		soundMap.put(5, soundPool.load(context, R.raw.four, 1));
		soundMap.put(6, soundPool.load(context, R.raw.sex, 1));

		mp = MediaPlayer.create(context, R.raw.one);// 创建mediaplayer对象
		mp.setOnCompletionListener(new OnCompletionListener() {

			@Override
			public void onCompletion(MediaPlayer arg0) {
				play(mPath);// 重新开始播放
			}
		});
	}
	/** 创建一个SoundPool （构造函数）
	public SoundPool(int maxStream, int streamType, int srcQuality) 
	maxStream —— 同时播放的流的最大数量
	streamType —— 流的类型，一般为STREAM_MUSIC(具体在AudioManager类中列出)
	srcQuality —— 采样率转化质量，当前无效果，使用0作为默认值
	 SoundPool适合 短小的 声音文件
	 SoundPool适合播放 “需要多次播放的提示音”，比如在 一些常用的 请登录，请点击什么的
	 相比mediaPlayer，耗用资源更少　
	 支持 同时 播放多个声音　
	 */

	/*初始化一个实例：
	/**
	 * 播放
	 * 
	 */
	public void play(int path) {
		try {
			if (mPath != path) {
				this.mPath = path;
				mp.reset();
				mp = MediaPlayer.create(context, path);// 重新设置要播放的音频
				mp.setLooping(true);
				mp.start();// 开始播放
			} else {
				if (!mp.isPlaying()) {
					this.mPath = path;
					mp.reset();
					mp = MediaPlayer.create(context, path);// 重新设置要播放的音频
					mp.setLooping(true);
					mp.start();// 开始播放
				}
			}
		} catch (Exception e) {
			e.printStackTrace();// 输出异常信息
		}
	}

	/**
	 * 停止播放
	 */
	public void stopPlay() {
		if (mp != null) {
			mp.stop();
		}
	}

	/**
	 * 按钮点击
	 * @param index
	 */
	public void getSoundIndex(int index) {
		soundPool.play(soundMap.get(index), 1, 1, 0, 0, 1);
	}
}
