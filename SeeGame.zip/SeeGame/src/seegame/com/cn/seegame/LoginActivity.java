package seegame.com.cn.seegame;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import seegame.com.cn.seegame.data.UserInfoData;
import seegame.com.cn.seegame.data.UserInfoDataDao;
import seegame.com.cn.seegame.dialog.BackDialog;
import seegame.com.cn.seegame.dialog.BackDialog.OnButtonClickListener;
import seegame.com.cn.seegame.util.SharedPreferencesUtils;
import seegame.com.cn.seegame.util.SoundPoolUtil;

/**
 * 登录界面
 */
public class LoginActivity extends Activity implements OnClickListener {
	private ImageButton btnBack, btnLogin, btnRegister;
	private EditText etName, etPassWord;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		initView();
		SoundPoolUtil.getInstance(this).play(R.raw.one);
	}

	private void initView() {
		btnBack = (ImageButton) findViewById(R.id.btn_back);
		btnLogin = (ImageButton) findViewById(R.id.btn_login);
		btnRegister = (ImageButton) findViewById(R.id.btn_regist);
		btnBack.setOnClickListener(this);
		btnLogin.setOnClickListener(this);
		btnRegister.setOnClickListener(this);
		etName = (EditText) findViewById(R.id.et_name);
		etPassWord = (EditText) findViewById(R.id.et_password);

	}

	@Override
	public void onClick(View v) {
		SoundPoolUtil.getInstance(this).getSoundIndex(1);
		switch (v.getId()) {
		case R.id.btn_back:
			back();
			break;
		case R.id.btn_login:
			login();
			break;
		case R.id.btn_regist:
			Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
			startActivity(intent);
			break;
		default:
			break;
		}
	}

	/**
	 * 返回
	 */
	private void back() {
		final BackDialog backDialog = new BackDialog(this);
		backDialog.setOnButtonClickListener(new OnButtonClickListener() {

			@Override
			public void onOKClicked() {
				backDialog.dismiss();
				SoundPoolUtil.getInstance(LoginActivity.this).getSoundIndex(1);
				LoginActivity.this.finish();
			}

			@Override
			public void onCancelClicked() {
				backDialog.dismiss();
				SoundPoolUtil.getInstance(LoginActivity.this).getSoundIndex(1);
			}
		});
		backDialog.show();
	}

	@Override
	public void onBackPressed() {
		back();
	}
@Override
protected void onDestroy() {
	super.onDestroy();
	SoundPoolUtil.getInstance(this).stopPlay();
}
	/**
	 * 登录
	 */
	private void login() {
		String strName = etName.getText().toString().trim();
		String strPassWord = etPassWord.getText().toString().trim();

		if (strName.equals("") || strPassWord.equals("")) {
			Toast.makeText(this, "请输入用户名或密码", Toast.LENGTH_SHORT).show();
			return;
		}
		UserInfoData userData = UserInfoDataDao.getInstance(this).login(strName, strPassWord);
		if (userData != null) {
			Intent intent = new Intent(this, MainActivity.class);
			SharedPreferencesUtils.setIntValue(this, "userId", userData.getId());
			startActivity(intent);
		} else {
			Toast.makeText(this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
		}
	}
}
