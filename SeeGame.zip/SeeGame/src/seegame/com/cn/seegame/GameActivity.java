package seegame.com.cn.seegame;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.SpeechSynthesizer;
import com.iflytek.cloud.ErrorCode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import seegame.com.cn.seegame.data.QuestionData;
import seegame.com.cn.seegame.data.QuestionDataDao;
import seegame.com.cn.seegame.data.RandomData;
import seegame.com.cn.seegame.data.TagData;
import seegame.com.cn.seegame.dialog.BackDialog;
import seegame.com.cn.seegame.dialog.BackDialog.OnButtonClickListener;
import seegame.com.cn.seegame.util.MyToast;
import seegame.com.cn.seegame.util.RandomUtil;
import seegame.com.cn.seegame.util.SharedPreferencesUtils;
import seegame.com.cn.seegame.util.SoundPoolUtil;
import seegame.com.cn.seegame.view.GameView;

/**
 * 游戏界面
 */
public class GameActivity extends Activity implements OnClickListener, OnCheckedChangeListener {
	// 两个进度条
	private SeekBar seekBar, seekBarLift;
	// 按秒计时，下面两个时间一定要相等
	int count = 60;
	int totlaCount = 60;
	private TimerTask timerTask;
	private Timer timer;
	// 游戏主view
	private RelativeLayout gameLayout;
	private OnClickListener puzzleClickListener;
	private List<QuestionData> datas;
	// 关卡和正确个数
	private TextView tvLevel, tvCount;
	// 正确个数
	private int trueCount = 0;
	private int level;
	private RadioGroup radioGroup;
	// 难易度时间
	private static final int easily = 90;
	private static final int medium = 60;
	private static final int difficulty = 40;
	private List<QuestionData> questionDatas;
	// 合成对象
	private SpeechSynthesizer speechSynthesizer;
	/**
	 * 备选项
	 */
	private GameView chooseGameView = null;
	@SuppressLint("HandlerLeak")
	private Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 1:
				seekBar.setProgress(totlaCount - count);
				seekBarLift.setSecondaryProgress(count);
				if (count < 10) {
					alertSound();//还剩下10s时间的时候 警报声响起
				}
				if (count == 0) {
					toFailResultActivity();
					timer.cancel();
				}
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game);
		// appid换成自己申请的
//		SpeechUser.getUser().login(GameActivity.this, null, null, "appid=12345678", listener);
		setParam();
		Bundle bundle = getIntent().getExtras();
		if (bundle != null) {
			level = bundle.getInt("level");
			questionDatas = QuestionDataDao.getInstance(this).getData(level);
			if (questionDatas == null) {
				return;
			}
			initData();
		}

	}

//讯飞语音技术选择里面哪一种声音
	public void setParam() {
		speechSynthesizer = SpeechSynthesizer.createSynthesizer(this, mTtsInitListener);
//		speechSynthesizer.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
		speechSynthesizer.setParameter(SpeechConstant.VOICE_NAME, "xiaoyan");
		speechSynthesizer.setParameter(SpeechConstant.SPEED, "20");
		speechSynthesizer.setParameter(SpeechConstant.VOLUME, "100");
		speechSynthesizer.setParameter(SpeechConstant.PITCH, "50");
	}

	/**
	 * 初始化监听。
	 */
	private InitListener mTtsInitListener = new InitListener() {
		@Override
		public void onInit(int code) {
			if (code != ErrorCode.SUCCESS) {
			} else {
				// 初始化成功，之后可以调用startSpeaking方法
				// 注：有的开发者在onCreate方法中创建完合成对象之后马上就调用startSpeaking进行合成，
				// 正确的做法是将onCreate中的startSpeaking调用移至这里
			}
		}
	};

	/**
	 * 加载数据
	 */
	private void initData() {
		datas = new ArrayList<QuestionData>();
		Collections.shuffle(questionDatas);
		if (questionDatas.size() > 10) {
			for (int i = 0; i < 10; i++) {
				datas.add(questionDatas.get(i));
			}
		} else {
			for (int i = 0; i < questionDatas.size(); i++) {
				datas.add(questionDatas.get(i));
			}
		}
		initView();
		SoundPoolUtil.getInstance(this).stopPlay();
		startTime();
		initGameView();
		addView();
	}

	private void initGameView() {
		puzzleClickListener = new OnClickListener() {

			@Override
			public void onClick(View v) {
				// 判断备选是否为空，不为空进行比较
				if (chooseGameView == null) {
					chooseGameView = (GameView) v;
				} else {
					// 相等，隐藏两个view
					TagData chooseTagData = (TagData) chooseGameView.getTag();
					TagData tagData = (TagData) v.getTag();
					if (chooseGameView != v && chooseTagData.getId() == tagData.getId()) {
						chooseGameView.setVisibility(View.INVISIBLE);
						v.setVisibility(View.INVISIBLE);
						GameView chooseView = (GameView) v;
						// SoundPoolUtil.getInstance(GameActivity.this).getSoundIndex(4);
						String strChoose = chooseView.getText().toString().trim();
						if (chooseTagData.isChinese()) {
							speechSynthesizer.startSpeaking(strChoose, null);
						} else if (tagData.isChinese()) {
							speechSynthesizer.startSpeaking(chooseGameView.getText().toString(), null);
						}

						MyToast.myTosat(GameActivity.this, chooseGameView.getText().toString() + "  " + strChoose, 6000,
								45);
						trueCount++;
						tvCount.setText(trueCount + "");
						chooseGameView = null;
						if (trueCount == datas.size()) {
							toResultActivity();
						}
					} else {
						SoundPoolUtil.getInstance(GameActivity.this).getSoundIndex(3);
						chooseGameView = null;
					}
				}
			}
		};
	}

	/**
	 * 到结果界面
	 */
	private void toResultActivity() {
		SharedPreferencesUtils.setBooleanValue(this, String.valueOf(level), true);
		Intent intent = new Intent();
		intent.putExtra("score", trueCount);
		intent.putExtra("level", level);
		intent.setClass(this, ResultActivity.class);
		startActivity(intent);
		this.finish();
	}

	/**
	 * 到结果界面
	 */
	private void toFailResultActivity() {
		Intent intent = new Intent();
		intent.setClass(this, FailActivity.class);
		startActivity(intent);
		this.finish();
	}

	/**
	 * 获取所有数据,将拼音和汉字组到一个list中
	 */
	private List<RandomData> getRandomList() {
		List<RandomData> randomDatas = new ArrayList<RandomData>();
		for (int i = 0; i < datas.size(); i++) {
			// 拼音
			RandomData randomDataP = new RandomData();
			randomDataP.setTag(datas.get(i).getId());
			randomDataP.setRandomValue(datas.get(i).getPinyin());
			randomDataP.setIsChinese(false);
			randomDatas.add(randomDataP);
			// 汉字
			RandomData randomDataC = new RandomData();
			randomDataC.setTag(datas.get(i).getId());
			randomDataC.setRandomValue(datas.get(i).getChinese());
			randomDataP.setIsChinese(true);
			randomDatas.add(randomDataC);
		}
		RandomUtil.randomSort(randomDatas);
		return randomDatas;
	}

	/**
	 * 添加视图
	 */
	private void addView() {
		gameLayout.removeAllViews();
		List<RandomData> randomDatas = getRandomList();
		for (int i = 0; i < randomDatas.size(); i++) {
			GameView puzzleView = new GameView(this);
			puzzleView.bindData(i + 1, randomDatas.get(i).getRandomValue(), randomDatas.get(i).getTag(),
					randomDatas.get(i).getIsChinese());
			puzzleView.setOnClickListener(puzzleClickListener);
			gameLayout.addView(puzzleView);
		}
	}

	private void initView() {
		seekBar = (SeekBar) findViewById(R.id.SeekBar);
		seekBarLift = (SeekBar) findViewById(R.id.seekbar_lift);
		gameLayout = (RelativeLayout) findViewById(R.id.game_layout);
		tvLevel = (TextView) findViewById(R.id.tv_level);
		tvCount = (TextView) findViewById(R.id.tv_count);
		radioGroup = (RadioGroup) findViewById(R.id.radio_group);
		radioGroup.setOnCheckedChangeListener(this);
		tvLevel.setText(level + "");
		tvCount.setText(trueCount + "");
		seekBarLift.setProgress(0);
		seekBarLift.setPressed(false);
		seekBar.setProgress(0);
		seekBar.setPressed(false);
		seekBar.setMax(totlaCount);
		seekBarLift.setMax(totlaCount);
	}

	/**
	 * 开始计时
	 */
	private void startTime() {
		if (timer != null) {
			timer.cancel();
		}
		timer = new Timer();
		timerTask = new TimerTask() {
			@Override
			public void run() {
				count--;
				handler.sendEmptyMessage(1);
			}
		};
		timer.schedule(timerTask, 0, 1000);
	}

	/**
	 * 报警
	 */
	private void alertSound() {
		SoundPoolUtil.getInstance(this).getSoundIndex(2);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_help:
			clickSound();
			MyToast.myTosat(this,
					"小朋友们要努力把汉字和他对应的拼音消掉噢！考验自己眼力的时候到啦！加油！底下一排的按钮可以自己选择完成本关卡的时间！选择初级、中级、高级按钮分别会有90s，60s，40s的时间哦！要抓紧时间啦！",
					18000, 25);//在util中把MyToast写的一个自定义函数
			break;
		case R.id.btn_back:
			clickSound();
			back();
			break;
		default:
			break;
		}

	}

	@Override
	public void onBackPressed() {
		back();
	}

	/**
	 * 按钮声音
	 */
	private void clickSound() {
		SoundPoolUtil.getInstance(this).getSoundIndex(1);
	}

	@Override
	protected void onStop() {
		super.onStop();
		// 停止播放
		SoundPoolUtil.getInstance(this).stopPlay();
	}

	/**
	 * 返回
	 */
	private void back() {
		final BackDialog backDialog = new BackDialog(this);
		backDialog.setOnButtonClickListener(new OnButtonClickListener() {

			@Override
			public void onOKClicked() {
				backDialog.dismiss();
				clickSound();
				GameActivity.this.finish();
			}

			@Override
			public void onCancelClicked() {
				clickSound();
				backDialog.dismiss();
			}
		});
		backDialog.show();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (timer != null) {
			timer.cancel();
		}
	}

	/**
	 * 改变时间，重新开始
	 * 
	 * @param chooseTime
	 */
	private void changeTime(int chooseTime) {
		count = chooseTime;
		totlaCount = chooseTime;
		initData();
	}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		switch (checkedId) {
		case R.id.easily:
			changeTime(easily);
			break;
		case R.id.medium:
			changeTime(medium);
			break;
		case R.id.difficulty:
			changeTime(difficulty);
			break;

		default:
			break;
		}

	}



}
