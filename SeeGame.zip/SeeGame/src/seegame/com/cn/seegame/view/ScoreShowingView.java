package seegame.com.cn.seegame.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import seegame.com.cn.seegame.R;

/**
 */
@SuppressLint("NewApi")
public class ScoreShowingView extends LinearLayout{
	private Context mContext;
	private View mMainView;
	private ImageView mImgOne;
	private ImageView mImgTwo;
	private ImageView mImgThree;
	private LinearLayout mLayoutProgressBar;
	private SpringProgressView mProgressBar;
	
	private TextView mTextFullScore;
	private TextView mTextNowScore;
	
	public ScoreShowingView(Context context) {
		super(context);
		this.mContext = context;
		initViews();
	}
	public ScoreShowingView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.mContext = context;
		initViews();
	}
	public ScoreShowingView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.mContext = context;
		initViews();
	}
	
	private void initViews() {
		mMainView = LayoutInflater.from(mContext).inflate(R.layout.view_scoreshowing, null);
		mTextFullScore = (TextView) mMainView.findViewById(R.id.text_scoreshowing_fullscore);
		mTextNowScore = (TextView) mMainView.findViewById(R.id.text_scoreshowing_score);
		mImgOne = (ImageView) mMainView.findViewById(R.id.img_scoreshowing_starone);
		mImgTwo = (ImageView) mMainView.findViewById(R.id.img_scoreshowing_startwo);
		mImgThree = (ImageView) mMainView.findViewById(R.id.img_scoreshowing_starthree);
		mLayoutProgressBar = (LinearLayout) mMainView.findViewById(R.id.layout_scoreshowing_progress);
		mProgressBar = (SpringProgressView) mMainView.findViewById(R.id.progress_scoreshowing_progress);
		mProgressBar.setMaxCount(100);
		float progressBarWdith = mContext.getResources().getDimension(R.dimen.width_200);
		mDistencePerPercent = progressBarWdith/100f;
		mLayoutProgressBar.setPadding(0, 0, (int)(progressBarWdith/16.0f), 0);
		this.addView(mMainView);
	}
	
	private static final int Min_Progress_Anim = 10;
	private int mNowScore;
	private int mMaxProgress = 0;
	private int mTempProgress = 0;
	private static final int FirstStar_Showing = 40;
	private static final int SecondStar_Showing = 60;
	private static final int thirdStar_Showing = 90;
	
	private float mDistencePerPercent = 1f;
	private float mScorePerPercent = 1f;
	
	private MainHandler mHandler;
	private static final int MSG_UPDATE = 0x100;
	private static final int MSG_UPDATE_MIN = 0x101;
	
	/**开始进度条
	 * @param maxScore
	 * @param nowScore
	 */
	public void show(int maxScore, int nowScore) {
		this.mNowScore = nowScore;
		
		mMaxProgress = (int) (100.0f*((float)nowScore / (float)maxScore));
		
		mScorePerPercent = (float)maxScore/100f;
		
		Log.e("", "mMaxProgress=" + mMaxProgress);
		mTextFullScore.setText(maxScore + "");
		mImgOne.setImageResource(R.drawable.ic_star_empty);
		mImgTwo.setImageResource(R.drawable.ic_star_empty);
		mImgThree.setImageResource(R.drawable.ic_star_empty);
		mTempProgress = 0;
		mHandler = new MainHandler();
		if(mMaxProgress >= Min_Progress_Anim) {
			mHandler.sendEmptyMessage(MSG_UPDATE);
		} else {
			mTempProgress = mTempProgress + Min_Progress_Anim;
			mHandler.sendEmptyMessageDelayed(MSG_UPDATE_MIN, 100);
		}
		
	}
	
	class MainHandler extends Handler {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case MSG_UPDATE:
				mTempProgress ++;
				if(mTempProgress == FirstStar_Showing) {
					mImgOne.setImageResource(R.drawable.ic_star_full);
				} else if(mTempProgress == SecondStar_Showing) {
					mImgTwo.setImageResource(R.drawable.ic_star_full);
				} else if(mTempProgress == thirdStar_Showing) {
					mImgThree.setImageResource(R.drawable.ic_star_full);
				}
				
				if(mTempProgress < mMaxProgress) {
					mProgressBar.setCurrentCount(mTempProgress);
					mHandler.sendEmptyMessageDelayed(MSG_UPDATE, 5 + (int)(mTempProgress*0.5));
				} 
				break;
				
			case MSG_UPDATE_MIN:
				mProgressBar.setCurrentCount(mTempProgress);
				break;

			default:
				break;
			}
		}
		
	}
	
}
	