package seegame.com.cn.seegame.view;

import android.content.Context;
import android.widget.Button;
import android.widget.RelativeLayout;
import seegame.com.cn.seegame.data.TagData;


public class GameView extends Button {

	/**
	 * 对应的数据
	 */

	private Context mContext;

	public GameView(Context context) {
		super(context);
		mContext = context;
		init(this);

	}

	/**
	 * 初始化
	 */
	private void init(GameView view) {
		setClickable(true);
		setPadding(10, 0, 10, 0);
	}

	/**
	 * 绑定数据
	 * 
	 * @param index
	 *            当前数据的索引
	 * @param data
	 *            对应的数据
	 * @param size
	 *            添加的总数
	 */
	public void bindData(int index, String value, int tag, boolean isChinese) {
		randomSetValue(index, value, tag, isChinese);
	}

	/**
	 * 设置词的位置
	 */
	private void randomSetValue(int index, String value, int tag, boolean isChinese) {
		setId(index);
		setText(value);
		TagData tagData = new TagData();
		tagData.setId(tag);
		tagData.setChinese(isChinese);
		setTag(tagData);
		RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(180, 180);
		int row = 0;
		// 每行显示4个
		for (int i = 1; i < 200; i++) {
			if (index <= i * 4) {
				row = i;
				break;
			}
		}
		int capIndex = index % 4;
		if (capIndex == 0) {
			capIndex = 4;
		}
		setParams(lp1, (capIndex - 1) * 180, (row - 1) * 180, 0, 0);
	}

	/**
	 * 设置显示位置
	 * 
	 * @param lp
	 * @param left
	 * @param top
	 * @param right
	 * @param bottom
	 */
	private void setParams(RelativeLayout.LayoutParams lp, int left, int top, int right, int bottom) {
		lp.setMargins(left, top, right, bottom);
		setLayoutParams(lp);
	}

	@Override
	public GameView clone() throws CloneNotSupportedException {
		GameView view = new GameView(mContext);
		init(view);
		view.setLayoutParams(getLayoutParams());
		return view;
	}
}
