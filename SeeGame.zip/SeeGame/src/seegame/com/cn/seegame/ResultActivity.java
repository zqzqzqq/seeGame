package seegame.com.cn.seegame;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import seegame.com.cn.seegame.data.LecelScoreData;
import seegame.com.cn.seegame.data.LevelScoreDataDao;
import seegame.com.cn.seegame.util.SharedPreferencesUtils;
import seegame.com.cn.seegame.util.SoundPoolUtil;

/**
 * 结果界面
 */
public class ResultActivity extends Activity implements OnClickListener {
	private ImageButton imageButton1, imageButton2, imageButton3;
	private ImageView imageView1, imageView2, imageView3;
	private TextView tvScore, heightScore;
	private int score, level;
	private static final int threeStar = 10;
	private static final int twoStar = 8;
	private static final int oneStar = 6;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_resule);
		Bundle bundle = getIntent().getExtras();
		if (bundle != null) {
			score = bundle.getInt("score");
			level = bundle.getInt("level");
		}
		// 播放成功音乐
//		SoundPoolUtil.getInstance(this).play(R.raw.four);
		SoundPoolUtil.getInstance(this).getSoundIndex(5);
		initView();
		setData();
	}

	private void setData() {
		LecelScoreData data = LevelScoreDataDao.getInstance(this)
				.getDataByLevel(SharedPreferencesUtils.getIntPreferences(this, "userId"), level);
		// 显示星星
		if (score >= threeStar) {
			imageView1.setBackgroundResource(R.drawable.ic_star_full);
			imageView2.setBackgroundResource(R.drawable.ic_star_full);
			imageView3.setBackgroundResource(R.drawable.ic_star_full);
		} else if (score >= twoStar) {
			imageView1.setBackgroundResource(R.drawable.ic_star_full);
			imageView2.setBackgroundResource(R.drawable.ic_star_full);
		} else if (score >= oneStar) {
			imageView1.setBackgroundResource(R.drawable.ic_star_full);
		}

		if (score != 0) {
			tvScore.setText(score + "0");
		} else {
			tvScore.setText("0");
		}
		// 判断本次成绩是否大于最高成绩
		if (data.getScore() > score) {
			heightScore.setText(data.getScore() + "0");
		} else {
			if (score != 0) {
				heightScore.setText(score + "0");
				// 将最高分更新到数据库
				LevelScoreDataDao.getInstance(this).updateUserAnswer(score, level,
						SharedPreferencesUtils.getIntPreferences(this, "userId"));
			} else {
				heightScore.setText("0");
			}
		}
	}

	private void initView() {
		imageButton1 = (ImageButton) findViewById(R.id.imageButton1);
		imageButton2 = (ImageButton) findViewById(R.id.imageButton2);
		imageButton3 = (ImageButton) findViewById(R.id.imageButton3);
		imageView1 = (ImageView) findViewById(R.id.imageView1);
		imageView2 = (ImageView) findViewById(R.id.imageView2);
		imageView3 = (ImageView) findViewById(R.id.imageView3);
		imageButton1.setOnClickListener(this);
		imageButton2.setOnClickListener(this);
		imageButton3.setOnClickListener(this);
		tvScore = (TextView) findViewById(R.id.tv_score);
		heightScore = (TextView) findViewById(R.id.height_score);
	}

	@Override
	public void onClick(View v) {
		SoundPoolUtil.getInstance(this).getSoundIndex(1);
		switch (v.getId()) {
		case R.id.imageButton1:
			Intent intent = new Intent(this, RankingListActivity.class);
			startActivity(intent);
			this.finish();
			break;
		case R.id.imageButton2:
			toGameActivity();
			break;
		case R.id.imageButton3:
			if (level < 3) {
				level = level + 1;
				toGameActivity();
			} else {
				Toast.makeText(this, "已经是最后一关", Toast.LENGTH_SHORT).show();
			}
			break;

		default:
			break;
		}
	}

	/**
	 * 到游戏界面
	 */
	private void toGameActivity() {
		Intent intent = new Intent(this, GameActivity.class);
		intent.putExtra("level", level);
		startActivity(intent);
		this.finish();
	}

	@Override
	protected void onStop() {
		super.onStop();
//		SoundPoolUtil.getInstance(this).stopPlay();
	}
}
