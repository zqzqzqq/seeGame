package seegame.com.cn.seegame;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import seegame.com.cn.seegame.data.LevelScoreDataDao;
import seegame.com.cn.seegame.data.UserInfoData;
import seegame.com.cn.seegame.data.UserInfoDataDao;
import seegame.com.cn.seegame.util.SharedPreferencesUtils;
import seegame.com.cn.seegame.util.SoundPoolUtil;
import seegame.com.cn.seegame.view.CircleImageView;

/**
 * 注册界面
 */
public class RegisterActivity extends Activity implements OnClickListener {
	private ImageButton btnBack, btnRegister;
	private EditText etName, etPassWord, etTel;

	/* 头像文件 */
	private static final String IMAGE_FILE_NAME = "temp_head_image.jpg";

	/* 请求识别码 */
	private static final int CODE_GALLERY_REQUEST = 0xa0;
	private static final int CODE_CAMERA_REQUEST = 0xa1;
	private static final int CODE_RESULT_REQUEST = 0xa2;

	// 裁剪后图片的宽(X)和高(Y),480 X 480的正方形。
	private static int output_X = 200;
	private static int output_Y = 200;

	private ImageView headImage = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		initView();
		// showImage();
	}

	private void showImage() {
		String filepath = SharedPreferencesUtils.getStringPreferences(this, "titleImageUrl");
		File file = new File(filepath);
		if (file.exists()) {
			Bitmap bm = BitmapFactory.decodeFile(filepath);
			// 将图片显示到ImageView中
			if (bm != null) {
				CircleImageView circleImageView=new CircleImageView(this);
				headImage.setImageBitmap(circleImageView.getCroppedRoundBitmap(bm, 140));
			}
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		showImage();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {

		// 用户没有进行有效的设置操作，返回
		if (resultCode == RESULT_CANCELED) {
			Toast.makeText(getApplication(), "取消", Toast.LENGTH_LONG).show();
			return;
		}

		switch (requestCode) {
		case CODE_GALLERY_REQUEST:
			cropRawPhoto(intent.getData());
			break;

		case CODE_CAMERA_REQUEST:
			if (hasSdcard()) {
				File tempFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), IMAGE_FILE_NAME);
				cropRawPhoto(Uri.fromFile(tempFile));
			} else {
				Toast.makeText(getApplication(), "没有SDCard!", Toast.LENGTH_LONG).show();
			}

			break;

		case CODE_RESULT_REQUEST:
			if (intent != null) {
				setImageToHeadView(intent);
			}

			break;
		}

		super.onActivityResult(requestCode, resultCode, intent);
	}

	/**
	 * 裁剪原始的图片
	 */
	public void cropRawPhoto(Uri uri) {

		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, "image/*");

		// 设置裁剪
		intent.putExtra("crop", "true");

		// aspectX , aspectY :宽高的比例
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);

		// outputX , outputY : 裁剪图片宽高
		intent.putExtra("outputX", output_X);
		intent.putExtra("outputY", output_Y);
		intent.putExtra("outputFormat", "JPEG");// 返回格式
		intent.putExtra("return-data", true);
		intent.putExtra("output", Uri.fromFile(new File(Environment.getExternalStorageDirectory(), IMAGE_FILE_NAME))); //保存路径

		startActivityForResult(intent, CODE_RESULT_REQUEST);
	}

	/**
	 * 提取保存裁剪之后的图片数据，并设置头像部分的View
	 */
	private void setImageToHeadView(Intent intent) {
		headImage = (ImageView) findViewById(R.id.img_title);
		headImage.setOnClickListener(this);
		File f = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), IMAGE_FILE_NAME);
		SharedPreferencesUtils.setStringValue(this, "titleImageUrl", f.getPath());
		Bundle extras = intent.getExtras();
		if (extras != null) {
			Bitmap photo = extras.getParcelable("data");
			CircleImageView circleImageView=new CircleImageView(this);
			headImage.setImageBitmap(circleImageView.getCroppedRoundBitmap(photo, 140));
			//saveBitmap(photo);
		}
		showImage();
	}

	private void saveBitmap(Bitmap bm) {
		File f = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), IMAGE_FILE_NAME);
		if (f.exists()) {
			f.delete();
		}
		SharedPreferencesUtils.setStringValue(this, "titleImageUrl", f.getPath());
		try {
			FileOutputStream out = new FileOutputStream(f);
			bm.compress(Bitmap.CompressFormat.JPEG, 60, out);
			out.flush();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * 检查设备是否存在SDCard的工具方法
	 */
	public static boolean hasSdcard() {
		String state = Environment.getExternalStorageState();
		if (state.equals(Environment.MEDIA_MOUNTED)) {
			// 有存储的SDCard
			return true;
		} else {
			return false;
		}
	}

	// // 启动手机相机拍摄照片作为头像
	// private void choseHeadImageFromCameraCapture() {
	// Intent intentFromCapture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	//
	// // 判断存储卡是否可用，存储照片文件
	// if (hasSdcard()) {
	// intentFromCapture.putExtra(MediaStore.EXTRA_OUTPUT, Uri
	// .fromFile(new File(Environment
	// .getExternalStorageDirectory(), IMAGE_FILE_NAME)));
	// }
	//
	// startActivityForResult(intentFromCapture, CODE_CAMERA_REQUEST);
	// }

	private void initView() {
		btnBack = (ImageButton) findViewById(R.id.btn_back);
		btnRegister = (ImageButton) findViewById(R.id.btn_register);
		btnBack.setOnClickListener(this);
		btnRegister.setOnClickListener(this);
		etName = (EditText) findViewById(R.id.et_name);
		etPassWord = (EditText) findViewById(R.id.et_password);
		etTel = (EditText) findViewById(R.id.et_tel);
		headImage = (ImageView) findViewById(R.id.img_title);
		headImage.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		SoundPoolUtil.getInstance(this).getSoundIndex(1);
		switch (v.getId()) {
		case R.id.btn_back:
			this.finish();
			break;
		case R.id.btn_register:
			register();
			break;
		case R.id.img_title:
			choseHeadImageFromGallery();
			break;
		default:
			break;
		}
	}

	// 从本地相册选取图片作为头像
	private void choseHeadImageFromGallery() {
		Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		startActivityForResult(i, CODE_GALLERY_REQUEST);
	}

	/**
	 * 注册
	 */
	private void register() {
		String strName = etName.getText().toString().trim();
		String strPassWord = etPassWord.getText().toString().trim();
		String strTel = etTel.getText().toString().trim();
		if (strName.equals("") || strPassWord.equals("") || strTel.equals("")) {
			Toast.makeText(this, "请输入用户名密码或手机号", Toast.LENGTH_SHORT).show();
			return;
		}

		ContentValues values = new ContentValues();
		values.put("USER_NAME", strName);
		values.put("PASS_WORD", strPassWord);
		values.put("TEL", strTel);
		UserInfoDataDao.getInstance(this).insertData(values);
		UserInfoData userData = UserInfoDataDao.getInstance(this).login(strName, strPassWord);
		if (userData != null) {
			Toast.makeText(this, "注册成功", Toast.LENGTH_SHORT).show();
			insertLevel(userData.getId());
			this.finish();
		}
	}

	/**
	 * 插入关卡数据
	 * 
	 * @param userId
	 */
	private void insertLevel(int userId) {
		List<ContentValues> valuesList = new ArrayList<ContentValues>();
		for (int i = 1; i <= 3; i++) {
			ContentValues values = new ContentValues();
			values.put("SCORE", 0);
			values.put("USER_ID", userId);
			values.put("LEVEL", i);
			values.put("IS_PASS", 0);
			valuesList.add(values);
		}
		LevelScoreDataDao.getInstance(this).bulkInsertData(valuesList);
	}
}
