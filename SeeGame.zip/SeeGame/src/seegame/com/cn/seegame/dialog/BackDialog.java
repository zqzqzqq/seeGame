package seegame.com.cn.seegame.dialog;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import seegame.com.cn.seegame.R;

/**
 * 返回dialog
 * 
 */
public class BackDialog extends BaseDialog implements android.view.View.OnClickListener {

	/**
	 * 取消，确定
	 */
	private Button btnCancel, btnOK;
	// 按钮点击监听
	private OnButtonClickListener mListener;

	/**
	 * 构造方法
	 * 
	 * @param context
	 * @param showTips
	 * @param btnOkString
	 * @param CancelString
	 * 
	 */
	public BackDialog(Context context) {
		super(context);

		setContentView(R.layout.dialog_back);
		init();
	}

	/**
	 * 初始化
	 */
	private void init() {
		btnCancel = (Button) this.findViewById(R.id.btn_cancel);
		btnOK = (Button) this.findViewById(R.id.btn_ok);
		btnCancel.setOnClickListener(this);
		btnOK.setOnClickListener(this);
	}


	/**
	 * 设置按钮点击监听
	 * 
	 * @param listener
	 */
	public void setOnButtonClickListener(OnButtonClickListener listener) {
		this.mListener = listener;
	}

	@Override
	public void onClick(View v) {
		if (mListener != null) {
			switch (v.getId()) {
			case R.id.btn_cancel:
				mListener.onCancelClicked();
				break;
			case R.id.btn_ok:
				mListener.onOKClicked();
				break;
			}
		}
	}

	/**
	 * 按钮点击监听
	 * 
	 * @author edu_lx
	 * 
	 */
	public interface OnButtonClickListener {
		/**
		 * 取消按钮点击
		 * 
		 */
		public void onCancelClicked();

		/**
		 * 确定按钮点击
		 * 
		 * @param editValue
		 */
		public void onOKClicked();
	}
}
