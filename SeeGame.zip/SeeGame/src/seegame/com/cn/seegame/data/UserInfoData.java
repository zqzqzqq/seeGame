package seegame.com.cn.seegame.data;

/**
 * 用户名密码
 */
public class UserInfoData extends BaseData {
	private static final long serialVersionUID = 1L;
	private String name;
	private String password;
	private String tel;

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
