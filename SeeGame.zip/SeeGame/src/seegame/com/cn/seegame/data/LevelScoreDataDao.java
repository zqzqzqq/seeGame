package seegame.com.cn.seegame.data;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.util.Log;
import seegame.com.cn.seegame.constant.Constant;

/**
 * 关卡
 */
public class LevelScoreDataDao extends BaseDataDao {

	/**
	 * 自身引用
	 */
	private static LevelScoreDataDao instance = null;

	protected LevelScoreDataDao(Context context, String dbName) {
		super(context, dbName);
	}

	@Override
	public void setTableName() {
		TABLE_NAME = "LEVEL_SCORE";

	}

	/**
	 * 获取实例
	 * 
	 * @return
	 */
	public static LevelScoreDataDao getInstance(Context context) {

		if (instance == null)
			instance = new LevelScoreDataDao(context, Constant.DATABASE_NAME);
		return instance;
	}

	/**
	 * 获取信息
	 * 
	 * @param userId
	 * @return
	 */
	public List<LecelScoreData> getData(int userId) {
		Cursor curs = null;
		List<LecelScoreData> datas = null;
		try {
			DBHelper helper = new DBHelper(mContext, Constant.DATABASE_NAME, null);
			mDb = helper.getWritableDatabase();
			String sql = "SELECT * FROM " + TABLE_NAME + " WHERE USER_ID = " + userId;
			Log.d(TAG, "sql:" + sql);
			curs = mDb.rawQuery(sql, null);
			if (curs != null && curs.getCount() != 0) {
				datas = new ArrayList<LecelScoreData>();
				while (curs.moveToNext()) {
					datas.add(parseCursor(curs));
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDb(mDb, curs);
		}
		return datas;
	}

	/**
	 * 获取信息
	 * 
	 * @param userId
	 * @return
	 */
	public LecelScoreData getDataByLevel(int userId, int level) {
		Cursor curs = null;
		try {
			DBHelper helper = new DBHelper(mContext, Constant.DATABASE_NAME, null);
			mDb = helper.getWritableDatabase();
			String sql = "SELECT * FROM " + TABLE_NAME + " WHERE USER_ID = " + userId + " and LEVEL= " + level;
			Log.d(TAG, "sql:" + sql);
			curs = mDb.rawQuery(sql, null);
			if (curs != null && curs.getCount() != 0) {
				curs.moveToNext();
				return parseCursor(curs);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDb(mDb, curs);
		}
		return null;
	}

	/**
	 * 更新分数
	 * 
	 * @param score
	 * @param level
	 * @param userId
	 */
	public void updateUserAnswer(int score, int level, int userId) {
		String sql = "UPDATE " + TABLE_NAME + " SET SCORE = " + score + " where LEVEL =" + level + " and USER_ID= "
				+ userId;
		Log.d(TAG, "sql:" + sql);
		DBHelper helper = new DBHelper(mContext, Constant.DATABASE_NAME, null);
		mDb = helper.getWritableDatabase();
		mDb.execSQL(sql);
	}

	@Override
	public LecelScoreData parseCursor(Cursor curs) {
		LecelScoreData data = new LecelScoreData();
		data.setId(curs.getInt(curs.getColumnIndex(ID)));
		data.setScore(curs.getInt(curs.getColumnIndex("SCORE")));
		data.setUserId(curs.getInt(curs.getColumnIndex("USER_ID")));
		data.setLevel(curs.getInt(curs.getColumnIndex("LEVEL")));
		data.setIsPass(curs.getInt(curs.getColumnIndex("IS_PASS")));
		return data;
	}

}
