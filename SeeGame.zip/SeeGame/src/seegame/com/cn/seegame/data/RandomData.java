package seegame.com.cn.seegame.data;

import java.io.Serializable;

public class RandomData implements Serializable {

	private static final long serialVersionUID = 1L;
	private int tag;
	private String randomValue;
	private boolean isChinese;// 是否是汉字

	public boolean getIsChinese() {
		return isChinese;
	}

	public void setIsChinese(boolean isChinese) {
		this.isChinese = isChinese;
	}

	public int getTag() {
		return tag;
	}

	public void setTag(int tag) {
		this.tag = tag;
	}

	public String getRandomValue() {
		return randomValue;
	}

	public void setRandomValue(String randomValue) {
		this.randomValue = randomValue;
	}

}
