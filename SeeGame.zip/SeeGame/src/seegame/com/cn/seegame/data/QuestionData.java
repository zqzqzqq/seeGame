package seegame.com.cn.seegame.data;

/**
 * 问题
 */
public class QuestionData extends BaseData {
	private static final long serialVersionUID = 1L;
	private String chinese;
	private String pinyin;
	private int level;

	public String getChinese() {
		return chinese;
	}

	public void setChinese(String chinese) {
		this.chinese = chinese;
	}

	public String getPinyin() {
		return pinyin;
	}

	public void setPinyin(String pinyin) {
		this.pinyin = pinyin;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

}
