package seegame.com.cn.seegame.data;

/**
 * 关卡和分数
 */
public class LecelScoreData extends BaseData {
	private static final long serialVersionUID = 1L;
	private int score;
	private int level;
	private int isPass;
	private int userId;

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getIsPass() {
		return isPass;
	}

	public void setIsPass(int isPass) {
		this.isPass = isPass;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}
