package seegame.com.cn.seegame.data;

/**
 * 用于区分拼音和汉字
 */
public class TagData {
	private int id;
	private boolean isChinese;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isChinese() {
		return isChinese;
	}

	public void setChinese(boolean isChinese) {
		this.isChinese = isChinese;
	}

}
