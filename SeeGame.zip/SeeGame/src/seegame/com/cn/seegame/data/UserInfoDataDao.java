package seegame.com.cn.seegame.data;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.util.Log;
import seegame.com.cn.seegame.constant.Constant;

/**
 * 用户信息
 */
public class UserInfoDataDao extends BaseDataDao {

	/**
	 * 自身引用
	 */
	private static UserInfoDataDao instance = null;

	protected UserInfoDataDao(Context context, String dbName) {
		super(context, dbName);
	}

	@Override
	public void setTableName() {
		TABLE_NAME = "USER_INFO";

	}

	/**
	 * 获取实例
	 * 
	 * @return
	 */
	public static UserInfoDataDao getInstance(Context context) {

		if (instance == null)
			instance = new UserInfoDataDao(context, Constant.DATABASE_NAME);
		return instance;
	}

	/**
	 * 登录
	 * 
	 * @param name
	 * @param password
	 * @return
	 */
	public UserInfoData login(String name, String password) {
		Cursor curs = null;
		UserInfoData datas = null;

		try {
			DBHelper helper = new DBHelper(mContext, Constant.DATABASE_NAME, null);
			mDb = helper.getWritableDatabase();
			String sql = "SELECT * FROM " + TABLE_NAME + " WHERE USER_NAME = '" + name + "' AND PASS_WORD = '"
					+ password + "'";
			Log.d(TAG, "sql:" + sql);
			curs = mDb.rawQuery(sql, null);
			if (curs != null && curs.getCount() != 0) {
				datas = new UserInfoData();
				curs.moveToFirst();
				datas = parseCursor(curs);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDb(mDb, curs);
		}
		return datas;
	}

	@Override
	public UserInfoData parseCursor(Cursor curs) {
		UserInfoData data = new UserInfoData();
		data.setId(curs.getInt(curs.getColumnIndex(ID)));
		data.setName(curs.getString(curs.getColumnIndex("USER_NAME")));
		data.setPassword(curs.getString(curs.getColumnIndex("PASS_WORD")));
		data.setTel(curs.getString(curs.getColumnIndex("TEL")));
		return data;
	}

}
