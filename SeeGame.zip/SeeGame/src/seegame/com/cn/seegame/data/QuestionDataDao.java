package seegame.com.cn.seegame.data;

import java.util.ArrayList;
import java.util.List;
import android.annotation.TargetApi;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Build;
import android.util.Log;
import seegame.com.cn.seegame.constant.Constant;

/**
 * 关卡
 */
@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
public class QuestionDataDao extends BaseDataDao {

	/**
	 * 自身引用
	 */
	private static QuestionDataDao instance = null;

	protected QuestionDataDao(Context context, String dbName) {
		super(context, dbName);
	}

	@Override
	public void setTableName() {
		TABLE_NAME = "QUESTION";

	}

	/**
	 * 获取实例
	 * 
	 * @return
	 */
	public static QuestionDataDao getInstance(Context context) {

		if (instance == null)
			instance = new QuestionDataDao(context, Constant.DATABASE_NAME);
		return instance;
	}

	/**
	 * 获取信息
	 * 
	 * @param userId
	 * @return
	 */
	public List<QuestionData> getData(int level) {
		Cursor curs = null;
		List<QuestionData> datas = null;
		try {
			DBHelper helper = new DBHelper(mContext, Constant.DATABASE_NAME, null);
			mDb = helper.getWritableDatabase();
			// String sql = "SELECT * FROM " + TABLE_NAME + " WHERE LEVEL = " +
			// level;
			// Log.d(TAG, "sql:" + sql);
			curs = mDb.query(true, TABLE_NAME, null, "LEVEL=?", new String[] { String.valueOf(level) }, "CHINESE", null,
					null, null, null);
			// curs = mDb.rawQuery(sql, null);
			if (curs != null && curs.getCount() != 0) {
				datas = new ArrayList<QuestionData>();
				while (curs.moveToNext()) {
					datas.add(parseCursor(curs));
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDb(mDb, curs);
		}
		return datas;
	}

	@Override
	public QuestionData parseCursor(Cursor curs) {
		QuestionData data = new QuestionData();
		data.setId(curs.getInt(curs.getColumnIndex(ID)));
		data.setChinese(curs.getString(curs.getColumnIndex("CHINESE")));
		data.setPinyin(curs.getString(curs.getColumnIndex("PINYIN")));
		data.setLevel(curs.getInt(curs.getColumnIndex("LEVEL")));
		return data;
	}

}