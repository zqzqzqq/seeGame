package seegame.com.cn.seegame;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import seegame.com.cn.seegame.dialog.BackDialog;
import seegame.com.cn.seegame.dialog.BackDialog.OnButtonClickListener;
import seegame.com.cn.seegame.util.SharedPreferencesUtils;
import seegame.com.cn.seegame.util.SoundPoolUtil;

/**
 * 关卡界面
 */
public class MainActivity extends Activity implements OnClickListener {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initView();
	}

	private void initView() {
		((ImageButton) findViewById(R.id.imageButton1)).setOnClickListener(this);
		((ImageButton) findViewById(R.id.imageButton2)).setOnClickListener(this);
		((ImageButton) findViewById(R.id.imageButton3)).setOnClickListener(this);
	}

	@Override
	protected void onResume() {
		super.onResume();
		SoundPoolUtil.getInstance(this).play(R.raw.one);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.imageButton1:
			clickSound();
			toGameActivity(1);
			break;
		case R.id.imageButton2:
			boolean unlock2 = SharedPreferencesUtils.getBooleanPreferences(this, "1");
			if(unlock2) {
				clickSound();
				toGameActivity(2);
			} else {
				android.widget.Toast.makeText(this, "必须先通过第1关才能进入第2关", android.widget.Toast.LENGTH_SHORT).show();
			}

			break;
		case R.id.imageButton3:
			boolean unlock3 = SharedPreferencesUtils.getBooleanPreferences(this, "2");
			if(unlock3) {
				clickSound();
				toGameActivity(3);
			} else {
				android.widget.Toast.makeText(this, "必须先通过第2关才能进入第3关", android.widget.Toast.LENGTH_SHORT).show();
			}

			break;
		case R.id.btn_back:
			clickSound();
			back();
			break;
		case R.id.btn_trophy:
			clickSound();
			Intent intent = new Intent(this, RankingListActivity.class);
			startActivity(intent);
			break;

		default:
			break;
		}
	}

	/**
	 * 跳到游戏界面
	 */
	private void toGameActivity(int level) {
		Intent intent = new Intent(this, GameActivity.class);
		intent.putExtra("level", level);
		startActivity(intent);
	}

	/**
	 * 按钮声音
	 */
	private void clickSound() {
		SoundPoolUtil.getInstance(this).getSoundIndex(1);
	}

	@Override
	public void onBackPressed() {
		back();
	}

	/**
	 * 返回
	 */
	private void back() {
		final BackDialog backDialog = new BackDialog(this);
		backDialog.setOnButtonClickListener(new OnButtonClickListener() {

			@Override
			public void onOKClicked() {
				backDialog.dismiss();
				clickSound();
				MainActivity.this.finish();
			}

			@Override
			public void onCancelClicked() {
				clickSound();
				backDialog.dismiss();
			}
		});
		backDialog.show();
	}
}
