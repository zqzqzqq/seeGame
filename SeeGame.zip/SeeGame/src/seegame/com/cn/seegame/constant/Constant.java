package seegame.com.cn.seegame.constant;

/**
 * 常量
 */
public class Constant {
	/**
	 * SharedPreferences文件名字
	 */
	public static final String SHARED_NAME = "config";
	/**
	 * 数据库名字
	 */
	public static final String DATABASE_NAME = "SeeGame.DB";
}
