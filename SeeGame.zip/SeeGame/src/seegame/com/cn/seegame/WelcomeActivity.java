package seegame.com.cn.seegame;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

import com.iflytek.cloud.SpeechConstant;

import seegame.com.cn.seegame.constant.Constant;
import seegame.com.cn.seegame.util.DBCopyUtil;
import seegame.com.cn.seegame.util.SoundPoolUtil;
import seegame.com.cn.seegame.view.ScoreShowingView;
import com.iflytek.cloud.SpeechUtility;

/**
 * 欢迎页
 */
public class WelcomeActivity extends Activity {
	private ScoreShowingView mScoreView;
	private LinearLayout parentView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welcome);
		initView();
		mScoreView.show(3000, 3000);
		// 拷贝数据库
		DBCopyUtil fileUtil = new DBCopyUtil(WelcomeActivity.this);
		fileUtil.checkDBVersion(Constant.DATABASE_NAME);
		SoundPoolUtil.getInstance(this).play(R.raw.one);

		SpeechUtility.createUtility(this, SpeechConstant.APPID +"=58bebac3");
	}

	private void initView() {
		mScoreView = (ScoreShowingView) findViewById(R.id.view_scoreshowing);
		parentView = (LinearLayout) findViewById(R.id.parent_view);
		parentView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				SoundPoolUtil.getInstance(WelcomeActivity.this).getSoundIndex(1);
				Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
				startActivity(intent);
				WelcomeActivity.this.finish();
			}
		});
	}

}
