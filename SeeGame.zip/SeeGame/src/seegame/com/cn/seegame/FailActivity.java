package seegame.com.cn.seegame;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import seegame.com.cn.seegame.util.SoundPoolUtil;

/**
 * 失败结果界面
 */
public class FailActivity extends Activity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fail_resule);
		// 播放失败音乐
		SoundPoolUtil.getInstance(this).getSoundIndex(6);
	}

	@Override
	public void onClick(View v) {
		SoundPoolUtil.getInstance(this).getSoundIndex(1);
		switch (v.getId()) {
		case R.id.btn_back:
			this.finish();
			break;
		default:
			break;
		}
	}

	@Override
	protected void onStop() {
		super.onStop();
//		SoundPoolUtil.getInstance(this).stopPlay();
	}
}
