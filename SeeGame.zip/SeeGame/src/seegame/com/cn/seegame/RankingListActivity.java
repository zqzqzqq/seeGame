package seegame.com.cn.seegame;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;

import seegame.com.cn.seegame.data.LecelScoreData;
import seegame.com.cn.seegame.data.LevelScoreDataDao;
import seegame.com.cn.seegame.util.SharedPreferencesUtils;
import seegame.com.cn.seegame.util.SoundPoolUtil;
import seegame.com.cn.seegame.view.CircleImageView;

/**
 * 排行榜
 */
public class RankingListActivity extends Activity implements OnClickListener {
	private List<LecelScoreData> datas;
	private TextView tvScore1, tvScore2, tvScore3;
	private ImageView star1, star2, star3, star4, star5, star6, star7, star8, star9;
	private RelativeLayout rlOne, rlTwo, rlThree;
	private ImageView headImage = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ranking_list);
		initView();
		// 获取3关数据
		datas = LevelScoreDataDao.getInstance(this).getData(SharedPreferencesUtils.getIntPreferences(this, "userId"));
		if (datas != null && datas.size() == 3) {
			setScore();
		} else {
			Toast.makeText(this, "关卡数不等于3", Toast.LENGTH_SHORT).show();
		}
		showImage();
	}

	private void showImage() {
		String filepath = SharedPreferencesUtils.getStringPreferences(this, "titleImageUrl");
		File file = new File(filepath);
		if (file.exists()) {
			Bitmap bm = BitmapFactory.decodeFile(filepath);
//			// 将图片显示到ImageView中
//			headImage.setImageBitmap(bm);
			CircleImageView circleImageView=new CircleImageView(this);
			headImage.setImageBitmap(circleImageView.getCroppedRoundBitmap(bm, 140));
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		SoundPoolUtil.getInstance(this).play(R.raw.one);
	}

	/**
	 * 显示最高分和星星
	 */
	private void setScore() {
		int score1 = datas.get(0).getScore();
		int score2 = datas.get(1).getScore();
		int score3 = datas.get(2).getScore();
		if (score1 != 0) {
			tvScore1.setText(score1 + "0");
		} else {
			tvScore1.setText("0");
			rlOne.setBackgroundResource(R.drawable.yingxiongbang4);
		}
		if (score2 != 0) {
			tvScore2.setText(score2 + "0");
		} else {
			tvScore2.setText("0");
			rlTwo.setBackgroundResource(R.drawable.yingxiongbang4);
		}
		if (score3 != 0) {
			tvScore3.setText(score3 + "0");
		} else {
			tvScore3.setText("0");
			rlThree.setBackgroundResource(R.drawable.yingxiongbang4);
		}

		showStar1(score1);
		showStar2(score2);
		showStar3(score3);
	}

	/**
	 * 显示第2关星星
	 * 
	 * @param score
	 */
	private void showStar2(int score) {
		if (score >= 10) {
			star4.setBackgroundResource(R.drawable.paihangbang5);
			star5.setBackgroundResource(R.drawable.paihangbang5);
			star6.setBackgroundResource(R.drawable.paihangbang5);
		} else if (score >= 8) {
			star4.setBackgroundResource(R.drawable.paihangbang5);
			star5.setBackgroundResource(R.drawable.paihangbang5);
		} else if (score >= 6) {
			star4.setBackgroundResource(R.drawable.paihangbang5);
		}
	}

	/**
	 * 显示第3关星星
	 * 
	 * @param score
	 */
	private void showStar3(int score) {
		if (score >= 10) {
			star7.setBackgroundResource(R.drawable.paihangbang5);
			star8.setBackgroundResource(R.drawable.paihangbang5);
			star9.setBackgroundResource(R.drawable.paihangbang5);
		} else if (score >= 8) {
			star7.setBackgroundResource(R.drawable.paihangbang5);
			star8.setBackgroundResource(R.drawable.paihangbang5);
		} else if (score >= 6) {
			star7.setBackgroundResource(R.drawable.paihangbang5);
		}
	}

	/**
	 * 显示第一关星星
	 * 
	 * @param score
	 */
	private void showStar1(int score) {
		if (score >= 10) {
			star1.setBackgroundResource(R.drawable.paihangbang5);
			star2.setBackgroundResource(R.drawable.paihangbang5);
			star3.setBackgroundResource(R.drawable.paihangbang5);
		} else if (score >= 8) {
			star1.setBackgroundResource(R.drawable.paihangbang5);
			star2.setBackgroundResource(R.drawable.paihangbang5);
		} else if (score >= 6) {
			star1.setBackgroundResource(R.drawable.paihangbang5);
		}
	}

	private void initView() {
		tvScore1 = (TextView) findViewById(R.id.textView1);
		tvScore2 = (TextView) findViewById(R.id.textView2);
		tvScore3 = (TextView) findViewById(R.id.textView3);
		star1 = (ImageView) findViewById(R.id.star1);
		star2 = (ImageView) findViewById(R.id.star2);
		star3 = (ImageView) findViewById(R.id.star3);
		star4 = (ImageView) findViewById(R.id.star4);
		star5 = (ImageView) findViewById(R.id.star5);
		star6 = (ImageView) findViewById(R.id.star6);
		star7 = (ImageView) findViewById(R.id.star7);
		star8 = (ImageView) findViewById(R.id.star8);
		star9 = (ImageView) findViewById(R.id.star9);
		rlOne = (RelativeLayout) findViewById(R.id.rl_one);
		rlTwo = (RelativeLayout) findViewById(R.id.rl_two);
		rlThree = (RelativeLayout) findViewById(R.id.rl_three);
		headImage = (ImageView) findViewById(R.id.img_title);
		headImage.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_back:
			SoundPoolUtil.getInstance(this).getSoundIndex(1);
			this.finish();
			break;
		default:
			break;
		}
	}
}
